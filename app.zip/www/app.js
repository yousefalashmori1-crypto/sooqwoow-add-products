const $=s=>document.querySelector(s);
const TAG="بانتظار الصور", API="2025-01";
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cfg=()=>{try{return JSON.parse(localStorage.getItem('cfg')||'{}')}catch(e){return{}}};
const saveCfg=c=>localStorage.setItem('cfg',JSON.stringify(c));
const say=(el,t,c)=>{el.innerHTML=`<div class="msg ${c||''}">${esc(t)}</div>`};
async function http(url,headers,method,body){
  if(window.electronAPI)return window.electronAPI.http(url,headers,method,body);
  const r=await fetch(url,{headers,method:method||'GET',body});return{status:r.status,body:await r.text()};}
let tok=null,tokAt=0;
async function token(){
  const c=cfg();
  if(c.clientId&&c.clientSecret){
    if(tok&&Date.now()-tokAt<20*3600e3)return tok;
    const r=await http(`https://${c.domain}/admin/oauth/access_token`,{'Content-Type':'application/x-www-form-urlencoded',Accept:'application/json'},'POST',`client_id=${encodeURIComponent(c.clientId)}&client_secret=${encodeURIComponent(c.clientSecret)}&grant_type=client_credentials`);
    let j={};try{j=JSON.parse(r.body)}catch(e){}
    if(!j.access_token)throw new Error('تعذر الحصول على مفتاح من شوبيفاي ('+r.status+'). تأكدي من Client ID وSecret وأن التطبيق مثبّت على المتجر.');
    tok=j.access_token;tokAt=Date.now();return tok;}
  if(c.token)return c.token;
  throw new Error('اذهبي للإعدادات وأدخلي نطاق المتجر والمفتاح.');}
async function gql(query,variables){
  const c=cfg();if(!c.domain)throw new Error('اذهبي للإعدادات وأدخلي نطاق المتجر.');
  const r=await http(`https://${c.domain}/admin/api/${API}/graphql.json`,{'Content-Type':'application/json','X-Shopify-Access-Token':await token()},'POST',JSON.stringify({query,variables}));
  if(r.status===401||r.status===403)throw new Error('المفتاح غير صالح أو ما عنده الصلاحية (يلزم قراءة وكتابة المنتجات).');
  if(r.status>=400)throw new Error('خطأ من شوبيفاي '+r.status);
  const j=JSON.parse(r.body);if(j.errors)throw new Error(j.errors.map(e=>e.message).join(' / '));return j.data;}
const uerr=o=>{const e=(o&&o.userErrors)||[];if(e.length)throw new Error(e.map(x=>x.message).join(' / '));};
const norm=s=>String(s||'').replace(/[ً-ْـ]/g,'').replace(/[أإآ]/g,'ا').replace(/\s+/g,' ').trim().toLowerCase();
const arDigits=s=>String(s||'').replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));
/* ---------- tabs ---------- */
function show(t){['add','list','set'].forEach(k=>{$('#'+k).classList.toggle('hide',k!==t)});
  document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('s',b.dataset.t!==t));
  if(t==='list')loadList();if(t==='set')buildSet();}
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>show(b.dataset.t));
/* ---------- add ---------- */
let photos={front:'',back:''};
function shrink(file){return new Promise((ok,no)=>{const im=new Image(),u=URL.createObjectURL(file);im.onload=()=>{const m=1000,k=Math.min(1,m/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);URL.revokeObjectURL(u);ok(c.toDataURL('image/jpeg',0.6))};im.onerror=()=>no(new Error('تعذر قراءة الصورة'));im.src=u;});}
function buildAdd(){
  photos={front:'',back:''};
  const ph=(k,t)=>`<div style="flex:1;text-align:center"><label style="margin:0 0 4px">${t}</label><div id="pv_${k}" style="height:110px;border:1px dashed var(--bd);border-radius:12px;display:flex;align-items:center;justify-content:center;overflow:hidden;color:var(--mu);font-size:13px">لا توجد صورة</div><input id="pf_${k}" type="file" accept="image/*" capture="environment" style="display:none"><button class="s" data-pk="${k}" style="width:100%;margin-top:6px;padding:8px">📷 تصوير</button></div>`;
  $('#add').innerHTML=`<div class="card"><div style="display:flex;gap:10px">${ph('front','صورة الأمام')}${ph('back','صورة الخلف')}</div>
  <label>اسم المنتج (اختياري إذا صوّرتِ المنتج)</label><input id="n" placeholder="مثال: زيت الخروع الجامايكي الأسود الداكن 118 مل"><label>الباركود (اختياري)</label><div style="display:flex;gap:6px"><input id="bc" inputmode="numeric" dir="ltr" placeholder="اكتبيه أو امسحي من الصورة"><button class="s" id="bs" style="white-space:nowrap">مسح</button></div>
  <label>سعر البيع (ر.ع)</label><input id="p" type="number" inputmode="decimal" step="0.001" placeholder="0.000">
  <label>سعر الشراء (اختياري)</label><input id="co" type="number" inputmode="decimal" step="0.001" placeholder="0.000">
  <label>السعر قبل الخصم (اختياري)</label><input id="cp" type="number" inputmode="decimal" step="0.001"><label>الماركة (اختياري)</label><input id="v"><label>ملاحظات لكلاود (اختياري)</label><textarea id="nt" rows="2"></textarea>
  <button id="go" style="width:100%;margin-top:14px">إضافة كمسودة بانتظار الصور</button><div id="m"></div>
  <small>يُحفظ المنتج مسودة في متجر سوق واو ولا يظهر للزبائن. بعدها اكتبي لكلاود: «كمّلي صور المنتجات». أطابق المنتج بالصورة أولًا، ثم الاسم، ثم الباركود.</small></div>`;
  document.querySelectorAll('[data-pk]').forEach(b=>b.onclick=()=>$('#pf_'+b.dataset.pk).click());
  ['front','back'].forEach(k=>$('#pf_'+k).onchange=async e=>{const f=e.target.files[0];if(!f)return;try{photos[k]=await shrink(f);$('#pv_'+k).innerHTML=`<img src="${photos[k]}" style="width:100%;height:100%;object-fit:cover">`;if(k==='back'||!$('#bc').value)tryBarcode(f);}catch(x){say($('#m'),x.message,'e')}});
  $('#bs').onclick=()=>{const f=$('#pf_back');f.click();};
  $('#go').onclick=add;}
async function tryBarcode(file){
  if(!('BarcodeDetector' in window))return;
  try{const bm=await createImageBitmap(file);const r=await new BarcodeDetector().detect(bm);if(r&&r[0]&&r[0].rawValue&&!$('#bc').value){$('#bc').value=r[0].rawValue;say($('#m'),'تم قراءة الباركود: '+r[0].rawValue,'g');}}catch(e){}}
async function uploadPhoto(dataUrl,name){
  const blob=await (await fetch(dataUrl)).blob();
  const d=await gql(`mutation($i:[StagedUploadInput!]!){stagedUploadsCreate(input:$i){stagedTargets{url resourceUrl parameters{name value}} userErrors{field message}}}`,{i:[{resource:'IMAGE',filename:name+'.jpg',mimeType:'image/jpeg',httpMethod:'POST'}]});
  uerr(d.stagedUploadsCreate);const t=d.stagedUploadsCreate.stagedTargets[0];
  const fd=new FormData();t.parameters.forEach(x=>fd.append(x.name,x.value));fd.append('file',blob,name+'.jpg');
  const f=window.CapacitorWebFetch||window.fetch;
  const r=await f(t.url,{method:'POST',body:fd});
  if(!(r.status>=200&&r.status<300))throw new Error('فشل رفع الصورة ('+r.status+')');
  return t.resourceUrl;}
async function add(){
  const m=$('#m'),b=$('#go');let n=$('#n').value.trim();const p=arDigits($('#p').value).trim(),cp=arDigits($('#cp').value).trim(),co=arDigits($('#co').value).trim(),bc=arDigits($('#bc').value).trim(),v=$('#v').value.trim(),nt=$('#nt').value.trim();
  const hasPh=photos.front||photos.back;
  if(!n&&!hasPh&&!bc)return say(m,'اكتبي اسم المنتج أو صوّريه أو اكتبي الباركود.','e');
  if(!(Number(p)>0))return say(m,'اكتبي سعر البيع.','e');
  if(cp&&!(Number(cp)>Number(p)))return say(m,'السعر قبل الخصم لازم يكون أكبر من السعر.','e');
  b.disabled=true;
  try{
    if(n){say(m,'أتأكد أن المنتج مو مكرر…');
      const d=await gql(`query($q:String!){products(first:10,query:$q){nodes{id title status}}}`,{q:n.split(' ').slice(0,4).join(' ')});
      const dup=d.products.nodes.find(x=>norm(x.title)===norm(n));
      if(dup&&!confirm('فيه منتج بنفس الاسم: «'+dup.title+'» ('+dup.status+'). تبين تضيفين غيره؟')){b.disabled=false;return say(m,'تم الإلغاء.');}}
    else n='منتج بانتظار التعرف '+new Date().toISOString().slice(5,16).replace('T',' ');
    say(m,'جاري إنشاء المنتج…');
    const body=nt?`<p>${esc(nt)}</p>`:'';
    const P={title:n,status:'DRAFT',tags:[TAG],...(v?{vendor:v}:{}),...(body?{descriptionHtml:body}:{})};
    const media=[];let photoWarn='';
    if(hasPh){say(m,'أرفع الصور…');for(const k of ['front','back']){if(!photos[k])continue;try{const u=await uploadPhoto(photos[k],'intake-'+k);media.push({originalSource:u,mediaContentType:'IMAGE',alt:'INTAKE-'+k});}catch(e){photoWarn=' (تنبيه: تعذر رفع صورة '+(k==='front'?'الأمام':'الخلف')+': '+e.message+')';}}}
    say(m,'جاري إنشاء المنتج…');
    const c=await gql(`mutation($p:ProductCreateInput!,$md:[CreateMediaInput!]){productCreate(product:$p,media:$md){product{id variants(first:1){nodes{id}}} userErrors{field message}}}`,{p:P,md:media});
    uerr(c.productCreate);const prod=c.productCreate.product;
    const V={id:prod.variants.nodes[0].id,price:String(p),...(cp?{compareAtPrice:String(cp)}:{}),...(bc?{barcode:bc}:{}),...(Number(co)>0?{inventoryItem:{cost:String(co)}}:{})};
    const u=await gql(`mutation($pid:ID!,$v:[ProductVariantsBulkInput!]!){productVariantsBulkUpdate(productId:$pid,variants:$v){userErrors{field message}}}`,{pid:prod.id,v:[V]});
    uerr(u.productVariantsBulkUpdate);
    say(m,'✔ تمت الإضافة كمسودة بانتظار الصور. كلاود يكمّل الصور تلقائيًا.'+photoWarn,'g');
    buildAdd2();
  }catch(e){say(m,e.message,'e');}
  b.disabled=false;}
function buildAdd2(){const msg=$('#m').innerHTML;buildAdd();$('#m').innerHTML=msg;}
/* ---------- list ---------- */
async function loadList(){
  const box=$('#list');box.innerHTML='<div class="msg">جاري التحميل…</div>';
  try{
    const Q=`query($q:String){products(first:50,query:$q,sortKey:CREATED_AT,reverse:true){nodes{id title status tags legacyResourceId mediaCount{count} featuredMedia{preview{image{url}}}}}}`;
    const [w,d]=await Promise.all([gql(Q,{q:`tag:"${TAG}"`}),gql(Q,{q:`status:draft AND NOT tag:"${TAG}"`})]);
    const store=cfg().domain.replace(/\.myshopify\.com.*$/,'');
    const row=(p,kind)=>{const im=p.featuredMedia&&p.featuredMedia.preview&&p.featuredMedia.preview.image?p.featuredMedia.preview.image.url:'';
      return`<div class="item">${im?`<img src="${esc(im)}">`:'<img>'}<div style="flex:1"><div>${esc(p.title)}</div><small>${p.mediaCount?p.mediaCount.count:0} صور</small><br><span class="tag ${kind}">${kind==='w'?'بانتظار الصور':'مسودة جاهزة للمراجعة'}</span></div><a href="https://admin.shopify.com/store/${esc(store)}/products/${esc(p.legacyResourceId)}" target="_blank" style="color:var(--pr)">فتح</a></div>`;};
    const nw=w.products.nodes.length;
    box.innerHTML=`<div class="card"><b>بانتظار الصور (${nw})</b>${nw?'<div style="margin:8px 0"><button id="cp" class="s" style="width:100%">نسخ الأمر لكلاود</button></div>':''}${w.products.nodes.map(p=>row(p,'w')).join('')||'<div><small>لا يوجد.</small></div>'}</div>
    <div class="card"><b>مسودات جاهزة للمراجعة</b>${d.products.nodes.slice(0,20).map(p=>row(p,'d')).join('')||'<div><small>لا يوجد.</small></div>'}</div><button class="s" id="rf" style="width:100%">تحديث</button>`;
    $('#rf').onclick=loadList;const cb=$('#cp');if(cb)cb.onclick=()=>{try{navigator.clipboard.writeText('كمّلي صور المنتجات');cb.textContent='تم النسخ ✔'}catch(e){alert('اكتبي لكلاود: كمّلي صور المنتجات')}};
  }catch(e){box.innerHTML=`<div class="msg e">${esc(e.message)}</div>`;}}
/* ---------- settings ---------- */
function buildSet(){const c=cfg();
  $('#set').innerHTML=`<div class="card"><label>نطاق المتجر (مثال: sooqwoow.myshopify.com)</label><input id="d" value="${esc(c.domain)}" dir="ltr">
  <label>مفتاح الوصول (Admin API access token) — اختياري إذا استخدمتِ Client ID وSecret</label><input id="t" type="password" value="${esc(c.clientId?'':c.token)}" dir="ltr">
  <label>Client ID (اختياري)</label><input id="ci" value="${esc(c.clientId)}" dir="ltr"><label>Client Secret</label><input id="cs" type="password" value="${esc(c.clientSecret)}" dir="ltr">
  <button id="sv" style="width:100%;margin-top:14px">حفظ واختبار الاتصال</button><div id="sm"></div><small>الصلاحيات المطلوبة: قراءة وكتابة المنتجات (read_products و write_products). المفتاح يُحفظ على جهازك فقط.</small></div>`;
  $('#sv').onclick=async()=>{const n={domain:$('#d').value.trim().replace(/^https?:\/\//,'').replace(/\/.*$/,''),token:$('#t').value.trim(),clientId:$('#ci').value.trim(),clientSecret:$('#cs').value.trim()};saveCfg(n);tok=null;
    const m=$('#sm');say(m,'أختبر الاتصال…');try{const d=await gql(`{shop{name}}`);say(m,'✔ متصل بمتجر: '+d.shop.name,'g');}catch(e){say(m,e.message,'e');}};}
buildAdd();if(!cfg().domain)show('set');
