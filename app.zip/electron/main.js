const { app, BrowserWindow, ipcMain, net, Menu } = require('electron');
const path = require('path');
ipcMain.handle('http', async (_e, url, headers, method, body) => {
  const r = await net.fetch(url, { headers, method: method || 'GET', body });
  return { status: r.status, body: await r.text(), link: r.headers.get('link') || '' };
});
app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  const w = new BrowserWindow({ width: 1280, height: 850, title: 'إضافة منتجات سوق واو',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true } });
  w.loadFile(path.join(__dirname, '..', 'www', 'index.html'));
});
app.on('window-all-closed', () => app.quit());
