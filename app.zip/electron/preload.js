const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('electronAPI', { http: (u, h, m, b) => ipcRenderer.invoke('http', u, h, m, b) });
